var express = require("express");
var Sequelize = require("sequelize");
var dbConfig = require("./db.config");
const { sendMsg } = require("./Helper/whatsapp");
var cors = require("cors");
var nodemailer=require("nodemailer");
const stripe = require("stripe")('sk_test_51K4s5ZSFHZzMVeSNU0TeF3doa76kxokvfDRzTkIOX9yAmHQzQ61CSzHfuxlc2MITLykn7Ui3EvQk9TyFeBcYeihu00Rnpbf4pw');

const app = express();
app.use(express.json());
app.use(cors());


//Connect to the db
const sequelize = new Sequelize(dbConfig.DB,dbConfig.USER,dbConfig.PASSWORD,{
    host:dbConfig.HOST,
    dialect:dbConfig.dialect,
    pool:{
        max:dbConfig.pool.max,
        min:dbConfig.pool.min,
        acquire:dbConfig.pool.acquire,
        idle:dbConfig.pool.idle
    }
});
// var transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//       user: '1998nik109@gmail.com',
//       pass: '*'
//     }
//   });
  
//   var mailOptions = {
//     from: '1998nik109@@gmail.com',
//     to: 'nikhil.khandelwal@mtxb2b.com',
//     subject: '',
//     text:''
//   };

sequelize.authenticate().then( ()=>{
    console.log("Connected to database successfully...");
}).catch(err => {
    console.error("Unable to connect to db, because" + err);
})

//Define the structure of Users table
let userTable = sequelize.define("Users",{
    email:{
        primaryKey:true,
        type:Sequelize.STRING
    },
    uname:Sequelize.STRING,
    // phoneNo:Sequelize.INTEGER,
    pwd:Sequelize.STRING
},{
    timestamps:false,
    freezeTableName:true
});

// userTable.sync({force:true}).then(()=>{
//     console.log("Table created successfully")
// }).catch (err => {
//     console.error("Error is : "+err);
// });

app.get("/",function(req,res){
    console.log("At GET of http://localhost:8002");
    res.send("Hello");
})

//Displays data of all Users
app.get("/getAllUsers",function(req,res){
    userTable.findAll({raw:true}).then(data=>{
        console.log(data);
        res.status(200).send(data);
    }).catch(err=>{
        console.error("There is an error getting data from db: " + err);
        res.status(400).send(err);
    })
})

//Display User based on email
app.get('/getUserByEmail/:email',function(req,res){
    var email=req.params.email;
    console.log("Given email: "+email)
    userTable.findByPk(email,{raw:true}).then(data=>{
        console.log(data);
        res.status(200).send(data)
    }).catch(err=>{
        console.error("There is an error getting data from db: "+err );
        res.status(400).send(err);
    })
})

// app.get("/getUserByEmail/:email",(req,res)=>{
//     console.log(data)

//     var email=req.params.email;
//     userTable.findByPk(email,{raw:true})
//     .then((data)=>{
//         if(data.length==0){
//             res.status(401).send("User not found")

//         }else{
//             mailOptions.to=email;
            
//             mailOptions.text='Your Password : '+data[2].pwd+'\nThankyou!\n our Best Team \n MTXShopify '
            
//             transporter.sendMail(mailOptions, function(error, info){
//                 if (error) {
//                     res.status(401).send(error)
//                 }
//                   });
//             res.status(200).send(data)
//         }
//     })
//     .catch((err)=>{
//         console.error(err);
//     })
// })

//Add new user data
app.post('/addUser',async function(req,res){
    var email=req.body.email;
    var uname =req.body.uname;
    // var phoneNo=req.body.phoneNo;
    var pwd=req.body.pwd;
    var userObj=userTable.build({email:email,uname:uname,pwd:pwd});
    const message = `Welcome ${req.body.uname} ! Welcome to MTX-Shop , Continue shopping with latest offer!`;
    await sendMsg("9818614023", message);
    userObj.save().then(data=>{
        var Msg="Record Inserted Successfully";
        res.status(201).send(data)
    }).catch(err=>{
        console.error("There is an error getting data from db: "+err );
        res.status(400).send(err);
    })
    var mailOptions = {
        from:'sharmajyotsana0210@gmail.com',
        to: `${req.body.email}`,
        subject:`Welcome, ${req.body.uname} to MTX Shopify`,
        html:`<h3>Dear ${req.body.uname}, <br>
            You have been successfully registered on MTX Shopify.<br>
            In case you need any support, you can write to support@mtxshopify.com.<br><br><br>
            With Regards,<br>
            MTX Shopify team</h3>`
    };
    
    transporter.sendMail(mailOptions,function(err,info){
        
if(err)
            console.error(err);
        else
            console.log('Email Sent : ' + info.response);
    })

    // const message = `Welcome ${req.body.uname} ! Welcome to PKS-Shop , Continue shopping with latest offer!`;
    // sendMsg("9818614023", message);

})
var transporter = nodemailer.createTransport({
    service:'gmail',
    auth:{
        user:'sharmajyotsana0210@gmail.com',
        pass:'sharma0210'
    }
});

// app.get("/getUserByEmail/:email",(req,res)=>{
 
//     console.log(data)
  

//     var email=req.params.email;
//     userTable.findAll({where:{email:email}},{raw:true})
//     .then((data)=>{
//         if(data.length==0){
//             res.status(401).send("User not found")

//         }else{
//             mailOptions.to=email;
            
//             mailOptions.text='Your Password : '+data[2].pwd+'\nThankyou!\n our Best Team \n MTXShopify '
            
//             transporter.sendMail(mailOptions, function(error, info){
//                 if (error) {
//                     res.status(401).send(error)
//                 }
//                   });
//             res.status(200).send(data)
//         }
//     })
//     .catch((err)=>{
//         console.error(err);
//     })
// })

// app.post("/emaill",function(req,res){
//     var email=req.body.email;
//     userTable.findAll({where: {
//         email:email}
//       },{raw:true}).then(data=>{
//         console.log(data);
//         res.status(200).send(data);
//     }).catch(err=>{
//         console.error("There is an error getting data from db: " + err);
//         res.status(400).send(err);
//     })

// })

//Delete user data
app.delete('/deleteUserByEmail/:email',function(req,res){
    var email=req.params.email;
    userTable.destroy({where:{email:email}})
    .then(data=>{
        console.log(data)
        var Msg="Record Deleted Successfully";
        res.status(200).send(Msg)
    }).catch(err=>{
            console.error("There is an error getting data from db: "+err );
            res.status(400).send(err);
    })
})

let productTable = sequelize.define("Products",{
    productId:{
        primaryKey:true,
        type:Sequelize.INTEGER
    },
    title:Sequelize.STRING,
    description:Sequelize.STRING,
    quantity:Sequelize.INTEGER,
    price:Sequelize.INTEGER,
    category:Sequelize.STRING,
    brand:Sequelize.STRING,
    image:Sequelize.STRING
},{
    timestamps:false,
    freezeTableName:true
});

// productTable.sync({force:true}).then(()=>{
//     console.log("Table created successfully")
// }).catch (err =>{
//     console.error("Error is : "+err);
// });




app.get("/getAllProducts",function(req,res){
    productTable.findAll({raw:true}).then(data=>{
        console.log(data);
        res.status(200).send(data);
    }).catch(err=>{
        console.error("There is an error getting data from db: " + err);
        res.status(400).send(err);
    })
})
app.post('/addProduct',function(req,res){
    var productId=req.body.productId;
    var title =req.body.title;
    var description=req.body.description;
    var quantity=req.body.quantity;
    var price=req.body.price;
    var category=req.body.category;
    var brand=req.body.brand;
    var image=req.body.image;
    var productObj=productTable.build({productId:productId,title:title,description:description,quantity:quantity,price:price,category:category,brand:brand,image});
    productObj.save().catch(err=>{
        console.error("There is an error getting data from db: "+err );
        res.status(400).send(err);
    })
})

//Delete user data
app.delete('/deleteProductById/:id',function(req,res){
    var productId=req.params.productId;
    userTable.destroy({where:{productId:productId}})
    .then(data=>{
        console.log(data)
        var Msg="Record Deleted Successfully";
        res.status(200).send(Msg)
    }).catch(err=>{
            console.error("There is an error getting data from db: "+err );
            res.status(400).send(err);
    })
})
let CartTable=sequelize.define('CartTable',{
    id:{
       primaryKey:true,
       type:Sequelize.INTEGER
     },
     productId:Sequelize.INTEGER,
     title:Sequelize.STRING,
    description:Sequelize.STRING,
    quantity:Sequelize.INTEGER,
    price:Sequelize.INTEGER,
    category:Sequelize.STRING,
    brand:Sequelize.STRING,
    image:Sequelize.STRING

},{
   timestamps:false,
   freezeTableName:true
});

// CartTable.sync({force:true}).then(()=>{
//     console.log("Table created successfully")
// }).catch (err =>{
//     console.error("Error is : "+err);
// });

app.post('/addProduct',function(req,res){
    var productId=req.body.productId;
    var title =req.body.title;
    var description=req.body.description;
    var quantity=req.body.quantity;
    var price=req.body.price;
    var category=req.body.category;
    var brand=req.body.brand;
    var image=req.body.image;
    var productObj=productTable.build({productId:productId,title:title,description:description,quantity:quantity,price:price,category:category,brand:brand,image});
    productObj.save().catch(err=>{
        console.error("There is an error getting data from db: "+err );
        res.status(400).send(err);
    })
})


app.post("/forgetpass",function(req,res){

    userTable.findOne({
        where: {
            email: req.body.email
        }
    }).then(user => {
       
        if (!user) {
          console.log("user not found");
            return res.status(201).send({
            message: "User Not Found",
          });
        }
      
        else{
           
             var otp = Math.floor(100000 + Math.random() * 900000);
            sendMail(user,otp,info=>
                {

                if(!user){ 
                    console.log("Not found");
                          return res.status(201).send({
                            message: "try later, unable to send mail."
                            });
                        } 
                     
                 else{

                 console.log("email sent with otp : "+otp+"\ninfo : "+info.response);
                 return res.status(201).send({
                     message: "OTP sent on this mail id.",
                      flag : true,
                     email: user.email,
                    otp : otp
                   });
                 }
             })
             }
      })
      .catch(err => {
        if (err.kind === "ObjectId") {
            return res.status(404).send({
            message: "Server error"
            });
          }
       
      });

})

app.put("/updatepass",function(req,res){
console.log("I iiiii");
    userTable.update({pwd : req.body.pwd},
        {where : { email: req.body.email}}).then(user => {
        sendMail2(req.body,info=>{
            res.status(201).send({
                message: "Password updated successfully."
            });
         })
      }).catch(err => {
        res.status(201).send({
          message: "Error updating Password with email=" + email
        });
    });

})




// async function sendMail1(user,callback)
//  {     console.log(user);
//      console.log(typeof user) 
      
//     console.log(user.email);
   
//   var transporter=nodemailer.createTransport({
    
//       service:'gmail',
     
//       auth:{
//           user:'sayendeeep1999@gmail.com',
//           pass:'Sayen@1999'
//       }
//   });
//   var mailOptions={
//       from:"sayendeep1999@gmail.com",
//       to:user.email,
//       subject:'Welcome to MTXShopify!! India  New Electronic Digital Market',
//       html:`<h1 style="color:coral;">Hi ${user.uname} ${user.uname},</h1><br>
//              <h4 style="color:aqua;">Thank you for joining Indiamart India growing
//               digital Electronics Market. <br> We will keep you posted with new offer and deal.<h4>
//               <h4 style="color:red;">Best wishes,</h4>
//                <b style="color:red;">Team Indiamart</b>`

//   };
//   let info= await transporter.sendMail(mailOptions);
//   callback(info);
// }

async function sendMail(user,otp,callback)
 {     
     console.log(user.email);
    //  console.log(typeof user) 
      
    // console.log(user.Emailno);
   
  var transporter=nodemailer.createTransport({
    
      service:'gmail',
     
      auth:{
          user:'sharmajyotsana0210@gmail.com',
          pass:'sharma0210'
      }
  });
  var mailOptions={
      from:"sharmajyotsana0210@gmail.com",
      to:user.email,
      subject:'Password Reset',
      html:`<h1 style="color:black;">Hello ${user.uname},</h1><br>
             <h4 style="color:black;">You are receiving this email beacuse we recieved
              a password reset request to your account <br> Your One time Password is :-<h4>`+otp+
        `<h4 style="color:red;">Best wishes,</h4>
               <b style="color:red;">Team MTXShopify</b>`

  };
  let info= await transporter.sendMail(mailOptions);
  callback(info);
}




async function sendMail2(user,callback)
 {    
      
  var transporter=nodemailer.createTransport({
    
      service:'gmail',
     
      auth:{
          user:'sharmajyotsana0210@gmail.com',
          pass:'sharma0210'
      }
  });
  
  var mailOptions={
      from:"sharmajyotsana0210@gmail.com",
      to:user.email,
      subject:'Password Successfully updated',
      html:`<h1 style="color:black;">Hi ${user},</h1><br>
             <h4 style="color:black;">Your Password is Successfully Changed 
             You can  login using the new password
              <h4 style="color:red;">Best wishes,</h4>
               <b style="color:red;">Team MTX Shopify</b>`

  };
  let info= await transporter.sendMail(mailOptions);
  callback(info);
}



app.post("/stripe", (req, res, next) => {
    stripe.charges.create({
        amount: req.body.amount *100,
        currency: 'INR',
        description: 'One time setup fee',
        source: req.body.token.id
    }, (err, charge) => {
        if(err){
            next(err);
        }
        res.json({success: true, status: "Payments Successful"})
    })
    console.log(req.body);
})








app.listen(8000,function(){
    console.log("Server is listening at http://localhost:8000")
})

