import { Injectable } from '@angular/core';
import { Router,CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardServiceService {

  constructor(private router:Router) { }
  canActivate(){
    let bReturn=true;
    if(localStorage.getItem('isLoggedIn')=='false'){
      alert("Sorry, You are not Allowed to view the pages");
      this.router.navigate(['/home']);
      bReturn=false;
    }
    return bReturn;
  }

}
