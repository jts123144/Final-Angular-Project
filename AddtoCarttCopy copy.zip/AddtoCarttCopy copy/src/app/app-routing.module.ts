import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './component/about/about.component';
import { CartComponent } from './component/cart/cart.component';
import { ContactComponent } from './component/contact/contact.component';
import { ProductsComponent } from './component/products/products.component';
import { UserDisplayComponent } from './component/user-display/user-display.component';
import { LoginComponent } from './component/login/login.component';
import { LogoutComponent } from './component/logout/logout.component';
import { AuthGuardServiceService } from './auth-guard-service.service';
import { PaymentComponent } from './component/payment/payment.component';
import { SignInComponent } from './component/sign-in/sign-in.component';
import { HomeComponent } from './component/home/home.component';
import { NopageComponent } from './component/nopage/nopage.component';
import { ForgetComponent } from './component/forget/forget.component';
import { SuccessfulPaymentComponent } from './component/successful-payment/successful-payment.component';








const routes: Routes = [
  {path:'', redirectTo:'login',pathMatch:'full'},
  {path:'products', component: ProductsComponent},
  {path:'cart', component: CartComponent},
  {path:'userDisplay',component:UserDisplayComponent,canActivate:[AuthGuardServiceService]},
  {path:'about',component:AboutComponent},
  {path:'contact',component:ContactComponent},
  {path:'login',component:LoginComponent},
  {path:'logout',component:LogoutComponent},
  {path:'payment',component:PaymentComponent},
  {path:'signin',component:SignInComponent},
  {path:'home',component:HomeComponent},
  {path:'forget',component:ForgetComponent},
  {path:'success',component:SuccessfulPaymentComponent},
  {path:'**',component:NopageComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
