import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';
import { FormGroup,FormBuilder, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginregisterService } from 'src/app/service/loginregister.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.css']
})
export class ForgetComponent implements OnInit {

  public forgetForm!:FormGroup;
  public otpForm!:FormGroup;
//   error:any=null;
//   success:boolean=false
//   public forgetForm!:FormGroup;
//   constructor(private fb:FormBuilder,private api:ApiService) { }

//   ngOnInit(): void {
//     this.forgetForm=this.fb.group(
//       {
//         email:['',[Validators.required,]]
//       }
      
//     )
//   }
//   get email() {
//     return this.forgetForm.get('email');
//  }
//   forgetsubmit()
//     {
//       if(this.forgetForm.valid)
//       {
//         // alert(this.forgetForm.get(['email'])?.value)
//         this.api.forgetpassword(this.forgetForm.get(['email'])?.value).subscribe(
//           (data)=>
//           {
            
//             this.success=true;
//             this.error=false;
//             console.log(data);
//           },
//           (err)=>
//           {
//             this.success=false;
//             console.log(this.forgetForm.value);
//             console.log(err);
//             this.error=err;
//           }
//         )
//       }

//     }

constructor(private formBuilder:FormBuilder,private api:ApiService,private LoginregisterService:LoginregisterService,private router:Router) { }


ngOnInit(): void {
  this.forgetForm=this.formBuilder.group({

    email :['',[Validators.required,Validators.email]],
    
  }),
  this.otpForm=this.formBuilder.group({
    email :['',[Validators.required,Validators.email]],
    otp:['',[Validators.required,Validators.email]],
    pwd:['',[Validators.required,Validators.email]],
    Cpwd :['',[Validators.required,Validators.email]],
  })
}
isforget=true;
isotp=false;
otp:any;
email:any;
sendmail1(){
  
  this.LoginregisterService.SendOTP({email:this.forgetForm.value.email}).subscribe 
    ( 
      
      (data) => 
      {
        data = JSON.parse(data);
        alert(data.message);
        // console.log("otp sent");
        if(data.flag==true){
          this.otp=data.otp;
          this.email=data.email;
          console.log("Otp"+this.otp+"email"+this.email);
          this.isforget=false;
          this.isotp=true;
        }
      }, 
      (error) => 
      {
        alert(JSON.parse(error));
        console.log("otp send failed" + error.getMessage);
      }
  );
}

verifyotp(){
  // this.submitted = true;
  let email= this.otpForm.value.email
  let otp = this.otpForm.value.otp;
  // let Password = this.otpForm.value.Password;
  var userObj = {
    "email" : this.otpForm.value.email,
    "pwd" : this.otpForm.value.pwd
  }
  // if(this.otpForm.invalid){
  //   alert("fill all details pls");
  //   return;
  // }
  // else{
    if(otp==this.otp && email==this.email){
      this.LoginregisterService.UpdatePassword(userObj).subscribe 
      ( 
        (data) => 
        {
          alert(JSON.parse(data).message);
          console.log("password updated");
          
          this.router.navigate(['/login']);
        }, 
        (error) => 
        {
          alert(JSON.parse(error));
          console.log("password reset failed" + error.getMessage);
        }
      );
    }
    else{
      if(this.email!=email)
        alert("Invalid mail");
      else
        alert("Invalid OTP");
     
    }   
}





}

