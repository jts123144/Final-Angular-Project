import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-successful-payment',
  templateUrl: './successful-payment.component.html',
  styleUrls: ['./successful-payment.component.css']
})
export class SuccessfulPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
