import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  public contactForm!:FormGroup;

  constructor(private formBuilder:FormBuilder,private http:HttpClient, private router:Router) { }

  ngOnInit(): void {

    // this.contactForm=this.formBuilder.group({
    //   name:[''],
    //   email:[''],
    //   telephone:[''],
    //   msg:['']
    // })
  }

    // contact(){

    //     this.http.post<any>("http://localhost:8000/addContact",this.contactForm.value)
    //     .subscribe(res=>{
    //       alert("Message Sent  Successfully");
    //       this.contactForm.reset();
    //       this.router.navigate(['/signin']);
    //     },err=>{
    //       alert("Something went wrong!!");
    //     })
    
    //   }

    }


