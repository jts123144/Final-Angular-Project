import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headernew',
  templateUrl: './headernew.component.html',
  styleUrls: ['./headernew.component.css']
})
export class HeadernewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
