export class policyModel{
    // id:number=0;
    // pName:string='';
    // pAmount:string='';
    // pEmi:string='';
    // pNominee:string='';

    uname:string='';
    email:string='';
    pwd:string='';
    // pNominee:string='';
}