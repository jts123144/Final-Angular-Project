import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { ApiService } from 'src/app/shared/api.service';
import { policyModel } from './policy.model';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ThrowStmt } from '@angular/compiler';



@Component({
  selector: 'app-user-display',
  templateUrl:'./user-display.component.html',
  styleUrls: ['./user-display.component.css']
 
})
export class UserDisplayComponent implements OnInit {

  formValue!:FormGroup;
   policyModelObj:policyModel=new policyModel();
   policyData:any;
   showAddData!:boolean;
   showUpdate!:boolean;

  constructor(private formbuilder:FormBuilder,private api:ApiService,private http:HttpClient, private router:Router) { }
  ngOnInit(): void {
    // this.api.getPolicy().subscribe((response)=>{
    //   this.policyData=response;
    // })
  this.formValue=this.formbuilder.group({
    // pName:[''],
    // pAmount:[''],
    // pEmi:[''],
    // pNominee:['']

    uname:[''],
      pwd:[''],
      email:['']
  })
  this.getAllPolicy();
  }

  clickAddPolicy(){
    this.formValue.reset();
    this.showAddData=true;
    this.showUpdate=false;
  }

  postPolicyDetails(){
    // this.policyModelObj.pName=this.formValue.value.pName;
    // this.policyModelObj.pAmount=this.formValue.value.pAmount;
    // this.policyModelObj.pEmi=this.formValue.value.pEmi;
    // this.policyModelObj.pNominee=this.formValue.value.pNominee;
    // this.policyModelObj.uname=this.formValue.value.uname;
    // this.policyModelObj.email=this.formValue.value.email;
    // this.policyModelObj.pwd=this.formValue.value.pwd;

    // this.api.postPolicy(this.policyModelObj)
    // .subscribe(res=>{
    //   console.log(res);
    //   alert("New User added successfully");
    //   let ref=document.getElementById("cancel");
    //   ref?.click();
    //   this.formValue.reset();
    //   this.getAllPolicy();
    // },
    // err=>{
    //   alert("Something went wrong");
    // }
    // )

    this.http.post<any>("http://localhost:8002/addUser",this.formValue.value)
    .subscribe(res=>{
      alert("Successfull");
      this.formValue.reset();
      this.router.navigate(['/userDisplay']);
    },err=>{
      alert("Something went wrong!!");
    })
  }

  getAllPolicy(){
    this.api.getPolicy()
    .subscribe(res=>{
      this.policyData=res;
    })
  }


  // deletePolicy(row:any){
  //   this.api.deletePolicy(row.id)
  //   .subscribe(res=>{
  //     alert("The Selected user is deleted");
  //     this.getAllPolicy();
  //   })
  // }
  onEdit(row:any){
    this.showAddData=false;
    this.showUpdate=true;
    // this.policyModelObj.id=row.id;
    this.formValue.controls['uname'].setValue(row.uname);
    this.formValue.controls['email'].setValue(row.email);
    this.formValue.controls['pwd'].setValue(row.pwd);
    // this.formValue.controls['pNominee'].setValue(row.pNominee);

  }
 
  // updatePolicyDetails(){
  //   this.policyModelObj.uname=this.formValue.value.uname;
  //   this.policyModelObj.email=this.formValue.value.email;
  //   this.policyModelObj.pwd=this.formValue.value.pwd;
  //   // this.policyModelObj.pNominee=this.formValue.value.pNominee;
  //   // this.api.updatePolicy(this.policyModelObj,this.policyModelObj.id)
  //   .subscribe(res=>{
  //     alert("Updated Successfully");
  //     let ref=document.getElementById("cancel");
  //     ref?.click();
  //     this.formValue.reset();
  //     this.getAllPolicy();
  //   })

  }













 




  
  



 
 
 




