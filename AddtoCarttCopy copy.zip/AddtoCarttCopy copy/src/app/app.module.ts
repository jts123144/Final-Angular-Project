import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxStripeModule } from 'ngx-stripe';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './component/header/header.component';
import { ProductsComponent } from './component/products/products.component';
import { CartComponent } from './component/cart/cart.component';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FilterPipe } from './shared/filter.pipe';

import { UserDisplayComponent } from './component/user-display/user-display.component';
import { HomeComponent } from './component/home/home.component';
import { AboutComponent } from './component/about/about.component';
import { ContactComponent } from './component/contact/contact.component';
import { HeadernewComponent } from './component/headernew/headernew.component';
import { FooterComponent } from './component/footer/footer.component';
import { LoginComponent } from './component/login/login.component';
import { LogoutComponent } from './component/logout/logout.component';
import { PaymentComponent } from './component/payment/payment.component';
import { SignInComponent } from './component/sign-in/sign-in.component';
import { NopageComponent } from './component/nopage/nopage.component';
import { ForgetComponent } from './component/forget/forget.component';
import { SuccessfulPaymentComponent } from './component/successful-payment/successful-payment.component';







@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ProductsComponent,
    CartComponent,
    FilterPipe,
    UserDisplayComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    HeadernewComponent,
    FooterComponent,
    LoginComponent,
    LogoutComponent,
    PaymentComponent,
    SignInComponent,
    NopageComponent,
    ForgetComponent,
    SuccessfulPaymentComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgxStripeModule.forRoot('pk_test_51K4s5ZSFHZzMVeSNz9rULnHXQgGAkOBDC2hHg7p1tYjfqAm7FdS5krXu0qjmYecd2oGHOb2pC7AD34We7r3hf2Sd00hBncKt8K'),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
